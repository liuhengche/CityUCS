/*
Copyright (C) 2016-2019 The University of Notre Dame
This software is distributed under the GNU General Public License.
See the file LICENSE for details.
*/

#ifndef MAIN_H
#define MAIN_H

/* nothing at the moment! */

#endif
