#include "helpers.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
// #include <string>
// #include <iostream>
#include <assert.h>
#include <errno.h>
#include <fcntl.h>   // This is necessary for using semaphore
#include <pthread.h> // This is necessary for Pthread
#include <pthread.h>
#include <semaphore.h> // This is necessary for using semaphore
#include <semaphore.h>
#include <string.h>
#include <sys/shm.h> // This is necessary for using shared memory constructs
#include <sys/wait.h>
#include <unistd.h>
#define NUM_THREADS 8

// using namespace std;

#define PARAM_ACCESS_SEMAPHORE "/param_access_semaphore"

long int global_param = 0;

int numbers[NUM_THREADS];
sem_t semaphores[NUM_THREADS];
/**
 * This function should be implemented by yourself. It must be invoked
 * in the child process after the input parameter has been obtained.
 * @parms: The input parameter from the terminal.
 */

void *thread_func(int res) {
    int thread_id = res;

    int digit1 = thread_id;
    int digit2 = thread_id + 1;
    if (digit2 == 8)
        digit2 = 0;

    while (1) {
        int result1 = sem_trywait(&semaphores[digit1]);
        int result2 = sem_trywait(&semaphores[digit2]);

        if (result1 == 0 && result2 == 0) {

            numbers[digit1] = (numbers[digit1] + 1) % 10;
            numbers[digit2] = (numbers[digit2] + 1) % 10;

            sem_post(&semaphores[digit1]);
            sem_post(&semaphores[digit2]);
            break;
        } else {
            if (result1 == 0) {
                sem_post(&semaphores[digit1]);
            }
            if (result2 == 0) {
                sem_post(&semaphores[digit2]);
            }
            usleep(100);
        }
    }
    // pthread_mutex_lock(&mutex);
    pthread_exit(NULL);
}

void multi_threads_run(long int input_param, int time, int flag) {

    pthread_t threads[NUM_THREADS];
    int tmp = (int)input_param, k = 7;
    if (time == 0) {
        while (tmp) {
            int res = tmp % 10;
            numbers[k] = res;
            tmp /= 10;
            k--;
        }
    }
    for (int i = 0; i < NUM_THREADS; i++) {
        sem_init(&semaphores[i], 0, 1);
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, thread_func, i);
    }

    for (int i = 0; i < NUM_THREADS; i++)
        pthread_join(threads[i], NULL);

    for (int i = 0; i < NUM_THREADS; i++) {
        sem_close(&semaphores[i]);
    }
    int output = 0;
    if (flag == -1) {
        for (int i = 0; i < NUM_THREADS; i++) {
            output += numbers[i];
            if (i != NUM_THREADS - 1)
                output *= 10;
        }
        // printf("%d\n",output);
        saveResult("p1_result.txt", output);
    }
}

int main(int argc, char **argv) {
    int shmid, status;
    long int local_param = 0;
    long int *shared_param_p, *shared_param_c;

    if (argc < 2) {
        printf("Please enter an eight-digit decimal number as the input parameter.\nUsage: ./main <input_param>\n");
        exit(-1);
    }
    // Checks if the semaphore exists, if it exists we unlink him from the process.
    sem_unlink(PARAM_ACCESS_SEMAPHORE);

    // Create the semaphore. sem_init() also creates a semaphore. Learn the difference on your own.
    sem_t *param_access_semaphore = sem_open(PARAM_ACCESS_SEMAPHORE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);

    // Check for error while opening the semaphore
    if (param_access_semaphore != SEM_FAILED) {
        printf("Successfully created new semaphore!\n");
    } else if (errno == EEXIST) { // Semaphore already exists
        printf("Semaphore appears to exist already!\n");
        param_access_semaphore = sem_open(PARAM_ACCESS_SEMAPHORE, 0);
    } else { // An other error occured
        assert(param_access_semaphore != SEM_FAILED);
        exit(-1);
    }

    /*
        Creating shared memory.
           The operating system keeps track of the set of shared memory
        segments. In order to acquire shared memory, we must first
        request the shared memory from the OS using the shmget()
          system call. The second parameter specifies the number of
        bytes of memory requested. shmget() returns a shared memory
        identifier (SHMID) which is an integer. Refer to the online
        man pages for details on the other two parameters of shmget()
    */
    shmid = shmget(IPC_PRIVATE, sizeof(long int), 0666 | IPC_CREAT); // We request an array of one long integer

    /*
        After forking, the parent and child must "attach" the shared
        memory to its local data segment. This is done by the shmat()
        system call. shmat() takes the SHMID of the shared memory
        segment as input parameter and returns the address at which
        the segment has been attached. Thus shmat() returns a char
        pointer.
    */

    if (fork() == 0) { // Child Process
        printf("Child Process: Child PID is %jd\n", (intmax_t)getpid());
        shared_param_c = (long int *)shmat(shmid, 0, 0);
        while (1) {
            sem_wait(param_access_semaphore);
            printf("Child Process: Got the variable access semaphore.\n");
            if ((global_param != 0) || (local_param != 0) || (shared_param_c[0] != 0)) {
                printf("Child Process: Read the global variable with value of %ld.\n", global_param);
                printf("Child Process: Read the local variable with value of %ld.\n", local_param);
                printf("Child Process: Read the shared variable with value of %ld.\n", shared_param_c[0]);
                // Release the semaphore
                sem_post(param_access_semaphore);
                printf("Child Process: Released the variable access semaphore.\n");

                break;
            }

            // Release the semaphore
            sem_post(param_access_semaphore);
            printf("Child Process: Released the variable access semaphore.\n");
        }

        /**
         * After you have fixed the issue in Problem 1-Q1,
         * uncomment the following multi_threads_run function
         * for Problem 1-Q2. Please note that you should also
         * add an input parameter for invoking this function,
         * which can be obtained from one of the three variables,
         * i.e., global_param, local_param, shared_param_c[0].
         */
        long int num = strtol(argv[2], NULL, 10);
        int flag = 0;
        // printf("%ld\n",num);
        int tmp = (int)num;
        for (int i = 0; i < tmp; i++) {
            if (i == tmp - 1)
                flag = -1;
            multi_threads_run(shared_param_c[0], i, flag);
        }
        /* each process should "detach" itself from the shared memory after it is used */

        shmdt(shared_param_c);

        exit(0);
    } else { // Parent Process
        printf("Parent Process: Parent PID is %jd\n", (intmax_t)getpid());

        /*  shmat() returns a long int pointer which is typecast here
            to long int and the address is stored in the long int pointer shared_param_p.
            Thus the memory location shared_param_p[0] of the parent
            is the same as the memory locations shared_param_c[0] of
            the child, since the memory is shared.
        */
        shared_param_p = (long int *)shmat(shmid, 0, 0);

        // Get the semaphore first
        sem_wait(param_access_semaphore);
        printf("Parent Process: Got the variable access semaphore.\n");

        global_param = strtol(argv[1], NULL, 10);
        local_param = strtol(argv[1], NULL, 10);
        shared_param_p[0] = strtol(argv[1], NULL, 10);
        // printf("Child Process: Read the global variable with value of %ld.\n", global_param);
        // printf("Child Process: Read the local variable with value of %ld.\n", local_param);
        // printf("Child Process: Read the shared variable with value of %ld.\n", shared_param_p[0]);
        //  Release the semaphore
        sem_post(param_access_semaphore);
        printf("Parent Process: Released the variable access semaphore.\n");
        // printf("Child Process: Read the shared variable with value of %ld.\n", shared_param_p[0]);
        wait(&status);

        /* each process should "detach" itself from the shared memory after it is used */

        shmdt(shared_param_p);

        shmctl(shmid, IPC_RMID, 0);

        // Close and delete semaphore.
        sem_close(param_access_semaphore);
        sem_unlink(PARAM_ACCESS_SEMAPHORE);

        exit(0);
    }

    exit(0);
}
