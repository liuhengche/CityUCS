#include "helpers.h"
#include <assert.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
/**
 * @brief This function recursively traverse the source directory.
 *
 * @param dir_name : The source directory name.
 */
void traverseDir(char *dir_name);
typedef struct QueueNode {
    char *file_name;
    struct QueueNode *next;
} QueueNode;
typedef struct Queue {
    QueueNode *head;
    QueueNode *tail;
} Queue;
Queue queue;
QueueNode *initQueue() {
    QueueNode *queueNode = (QueueNode *)malloc(sizeof(QueueNode));
    queueNode->next = NULL;
    return queue.head = queue.tail = queueNode;
}
QueueNode *enQueue(QueueNode *tail, char *file_name) {
    QueueNode *newNode = (QueueNode *)malloc(sizeof(QueueNode));
    newNode->file_name = file_name;
    newNode->next = NULL;
    tail->next = newNode;
    tail = newNode;
    return tail;
}
int isEmpty(QueueNode *head, QueueNode *tail) {
    if (head->next == NULL) {
        return 1;
    }
    return 0;
}
char *deQueue(QueueNode *head, QueueNode *tail) {
    if (head->next == NULL) {
        printf("error");
        return "";
    }
    QueueNode *now = head->next;
    char *res = now->file_name;
    head->next = now->next;
    if (tail == now) {
        tail = head;
    }
    free(now);
    return res;
}
#define POISON_PILL "poison_pill_plz_kill_yourself"
sem_t *full_sem, *empty_sem;
int shmid;
int word_count = 0;
int main(int argc, char **argv) {
    int process_id; // Process identifier
    char *dir_name = argv[1];
    for (int pos = 0; pos < strlen(dir_name); pos++) {
        if (dir_name[pos] == '/') {
            dir_name[pos] = '\0';
            break;
        }
    }
    if (argc < 2) {
        printf("Main process: Please enter a source directory name.\nUsage: ./main <dir_name>\n");
        exit(-1);
    }
    initQueue();
    traverseDir(dir_name);

    char *shared_memory;
    shmid = shmget(IPC_PRIVATE, 1024 * 1024, IPC_CREAT | 0666);
    sem_unlink("FULL_SEM");
    sem_unlink("EMPTY_SEM");
    full_sem = sem_open("FULL_SEM", O_CREAT, 0666, 0);
    if (full_sem != SEM_FAILED) {
        printf("Full semaphore created.\n");
    } else if (errno == EEXIST) {
        printf("Full semaphore already exists.\n");
        sem_open("FULL_SEM", 0);
    } else {
        printf("Full semaphore creation failed.\n");
        exit(1);
    }
    empty_sem = sem_open("EMPTY_SEM", O_CREAT, 0666, 1);
    if (empty_sem != SEM_FAILED) {
        printf("Empty semaphore created.\n");
    } else if (errno == EEXIST) {
        printf("Empty semaphore already exists.\n");
        sem_open("EMPTY_SEM", 0);
    } else {
        printf("Empty semaphore creation failed.\n");
        exit(1);
    }
    switch (process_id = fork()) {
    default:
        printf("Parent process: My ID is %jd\n", (intmax_t)getpid());
        while (!isEmpty(queue.head, queue.tail)) {
            sem_wait(empty_sem);
            char *file_name = deQueue(queue.head, queue.tail);
            FILE *read = fopen(file_name, "r");
            if (read == NULL) {
                printf("Open File %s Error: %s\n", file_name, strerror(errno));
                exit(1);
            }
            char *buf = (char *)malloc(sizeof(char) * fileLength(read) + 128);
            memset(buf, 0, sizeof(char) * fileLength(read) + 128);
            fread(buf, sizeof(char), fileLength(read), read);
            fclose(read);
            shared_memory = shmat(shmid, NULL, 0);
            if (strlen(buf) >= 1024 * 1024) {
                int last_pos = 0, start_pos = 0;
                for (int pos = 1024*1023; pos < strlen(buf); pos++ ) {
                    if (buf[pos] == ' ' || buf[pos] == '\t' || buf[pos] == '\n') {
                        //printf("%d\n",pos - start_pos);
                        if (pos - start_pos >= 1024 * 1024) {
                            memcpy(shared_memory, buf + start_pos, last_pos - start_pos);
                            shared_memory[last_pos - start_pos] = '\0';
                            shmdt(shared_memory);
                            start_pos = last_pos + 1;
                            sem_post(full_sem);
                            sem_wait(empty_sem);
                            shared_memory = shmat(shmid, NULL, 0);
                            pos += 1024*1023;
                        }
                        last_pos = pos;
                    }
                }
                strcpy(shared_memory, buf + start_pos);
                shmdt(shared_memory);
                sem_post(full_sem);
            } else {
                strcpy(shared_memory, buf);
                shmdt(shared_memory);
                sem_post(full_sem);
            }

            free(buf);
            free(file_name);
        }
        sem_wait(empty_sem);
        shared_memory = shmat(shmid, NULL, 0);
        strcpy(shared_memory, POISON_PILL);
        shmdt(shared_memory);
        sem_post(full_sem);
        puts("Parent process: All files have been read.");
        waitpid(process_id, NULL, 0);
        shmctl(shmid, IPC_RMID, NULL);
        printf("Parent process: Finished.\n");
        break;

    case 0:
        printf("Child process: My ID is %jd\n", (intmax_t)getpid());
        while (1) {
            sem_wait(full_sem);
            char *shared_memory = (char *)shmat(shmid, NULL, 0);
            if (strcmp(shared_memory, POISON_PILL) == 0) {
                shmdt(shared_memory);
                sem_post(full_sem);
                break;
            }
            int count = wordCount(shared_memory);
            shmdt(shared_memory);
            sem_post(empty_sem);
            word_count += count;
        }

        saveResult("p2_result.txt", word_count);
        printf("Child process: Finished.\n");
        exit(0);

    case -1:
        /*
        Error occurred.
        */
        printf("Fork failed!\n");
        exit(-1);
    }
    sem_close(full_sem);
    sem_close(empty_sem);
    return 0;
}

/**
 * @brief This function recursively traverse the source directory.
 *
 * @param dir_name : The source directory name.
 */
int cnt = 0;
void traverseDir(char *dir_name) {
    DIR *dirp;
    struct dirent *direntp;

    if ((dirp = opendir(dir_name)) == NULL) {
        printf("Open Directory %s Error: %s\n", dir_name, strerror(errno));
        exit(1);
    }

    while ((direntp = readdir(dirp)) != NULL) {
        char *file_name = (char *)malloc(sizeof(char) * 1024);
        memset(file_name, 0, sizeof(char) * 1024);
        strcpy(file_name, dir_name);
        strcat(file_name, "/");
        strcat(file_name, direntp->d_name);
        struct stat statbuf;
        if (stat(file_name, &statbuf) == -1) {
            printf("Get stat on %s Error: %s\n", file_name, strerror(errno));
            exit(1);
        }
        if (S_ISDIR(statbuf.st_mode)) {
            if (strcmp(direntp->d_name, ".") == 0 || strcmp(direntp->d_name, "..") == 0) {
                free(file_name);
                continue;
            }
            traverseDir(file_name);
            free(file_name);
        }
        if (S_ISREG(statbuf.st_mode)) {
            if (validateTextFile(file_name) == 0) {
                free(file_name);
                continue;
            }
            queue.tail = enQueue(queue.tail, file_name);
        }
    }
    closedir(dirp);
}
