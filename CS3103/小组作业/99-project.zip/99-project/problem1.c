#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <sys/shm.h>   // This is necessary for using shared memory constructs
#include <semaphore.h> // This is necessary for using semaphore
#include <fcntl.h>	   // This is necessary for using semaphore
#include <pthread.h>   // This is necessary for Pthread
#include <string.h>
#include "helpers.h"


#define PARAM_ACCESS_SEMAPHORE "/param_access_semaphore"

#define DIGIT_ONE "/digit_one"
#define DIGIT_TWO "/digit_two"
#define DIGIT_THREE "/digit_three"
#define DIGIT_FOUR "/digit_four"
#define DIGIT_FIVE "/digit_five"
#define DIGIT_SIX "/digit_six"
#define DIGIT_SEVEN "/digit_seven"
#define DIGIT_EIGHT "/digit_eight"


sem_t *digit_one;
sem_t *digit_two;
sem_t *digit_three;
sem_t *digit_four;
sem_t *digit_five;
sem_t *digit_six;
sem_t *digit_seven;
sem_t *digit_eight;

long int global_param = 0;

/**
 * This function should be implemented by yourself. It must be invoked
 * in the child process after the input parameter has been obtained.
 * @params: The input parameter from the terminal.
 */
void multi_threads_run(long int input_param, long int loop_num);

int main(int argc, char **argv)
{
	int shmid, status;
	long int local_param = 0;
	long int *shared_param_p, *shared_param_c;

	if (argc < 2)
	{
		printf("Please enter an eight-digit decimal number as the input parameter.\nUsage: ./main <input_param>\n");
		exit(-1);
	}

	/*
		Creating semaphores. Mutex semaphore is used to acheive mutual
		exclusion while processes access (and read or modify) the global
		variable, local variable, and the shared memory.
	*/

	// Checks if the semaphore exists, if it exists we unlink him from the process.
	sem_unlink(PARAM_ACCESS_SEMAPHORE);

	// Create the semaphore. sem_init() also creates a semaphore. Learn the difference on your own.
	sem_t *param_access_semaphore = sem_open(PARAM_ACCESS_SEMAPHORE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);

	// Check for error while opening the semaphore
	if (param_access_semaphore != SEM_FAILED)
	{
		printf("Successfully created new semaphore!\n");
	}
	else if (errno == EEXIST)
	{ // Semaphore already exists
		printf("Semaphore appears to exist already!\n");
		param_access_semaphore = sem_open(PARAM_ACCESS_SEMAPHORE, 0);
	}
	else
	{ // An other error occured
		assert(param_access_semaphore != SEM_FAILED);
		exit(-1);
	}

	/*
		Creating shared memory.
		The operating system keeps track of the set of shared memory
		segments. In order to acquire shared memory, we must first
		request the shared memory from the OS using the shmget()
		system call. The second parameter specifies the number of
		bytes of memory requested. shmget() returns a shared memory
		identifier (SHMID) which is an integer. Refer to the online
		man pages for details on the other two parameters of shmget()
	*/
	shmid = shmget(IPC_PRIVATE, sizeof(long int), 0666 | IPC_CREAT); // We request an array of one long integer

	/*
		After forking, the parent and child must "attach" the shared
		memory to its local data segment. This is done by the shmat()
		system call. shmat() takes the SHMID of the shared memory
		segment as input parameter and returns the address at which
		the segment has been attached. Thus shmat() returns a char
		pointer.
	*/

	if (fork() == 0)
	{ // Child Process

		printf("Child Process: Child PID is %jd\n", (intmax_t)getpid());

		/*  shmat() returns a long int pointer which is typecast here
			to long int and the address is stored in the long int pointer shared_param_c. */
		shared_param_c = (long int *)shmat(shmid, 0, 0);

		while (1) // Loop to check if the variables have been updated.
		{
			// Get the semaphore
			sem_wait(param_access_semaphore);
			printf("Child Process: Got the variable access semaphore.\n");

			if ((global_param != 0) || (local_param != 0) || (shared_param_c[0] != 0))
			{
				printf("Child Process: Read the global variable with value of %ld.\n", global_param);
				printf("Child Process: Read the local variable with value of %ld.\n", local_param);
				printf("Child Process: Read the shared variable with value of %ld.\n", shared_param_c[0]);

				// Release the semaphore
				sem_post(param_access_semaphore);
				printf("Child Process: Released the variable access semaphore.\n");

				break;
			}

			// Release the semaphore
			sem_post(param_access_semaphore);
			printf("Child Process: Released the variable access semaphore.\n");
		}

		/**
		 * After you have fixed the issue in Problem 1-Q1,
		 * uncomment the following multi_threads_run function
		 * for Problem 1-Q2. Please note that you should also
		 * add an input parameter for invoking this function,
		 * which can be obtained from one of the three variables,
		 * i.e., global_param, local_param, shared_param_c[0].
		 */
		multi_threads_run(shared_param_c[0], strtol(argv[2], NULL, 10));

		/* each process should "detach" itself from the
		   shared memory after it is used */

		shmdt(shared_param_c);

		exit(0);
	}
	else
	{ // Parent Process

		printf("Parent Process: Parent PID is %jd\n", (intmax_t)getpid());

		/*  shmat() returns a long int pointer which is typecast here
			to long int and the address is stored in the long int pointer shared_param_p.
			Thus the memory location shared_param_p[0] of the parent
			is the same as the memory locations shared_param_c[0] of
			the child, since the memory is shared.
		*/
		shared_param_p = (long int *)shmat(shmid, 0, 0);

		// Get the semaphore first
		sem_wait(param_access_semaphore);
		printf("Parent Process: Got the variable access semaphore.\n");

		global_param = strtol(argv[1], NULL, 10);
		local_param = strtol(argv[1], NULL, 10);
		shared_param_p[0] = strtol(argv[1], NULL, 10);

		// Release the semaphore
		sem_post(param_access_semaphore);
		printf("Parent Process: Released the variable access semaphore.\n");

		wait(&status); // calling process until one of its child processes exits or a signal is received

		/* each process should "detach" itself from the
		   shared memory after it is used */

		shmdt(shared_param_p);

		/* Child has exited, so parent process should delete
		   the cretaed shared memory. Unlike attach and detach,
		   which is to be done for each process separately,
		   deleting the shared memory has to be done by only
		   one process after making sure that noone else
		   will be using it
		 */

		shmctl(shmid, IPC_RMID, 0);

		// Close and delete semaphore.
		sem_close(param_access_semaphore);
		sem_unlink(PARAM_ACCESS_SEMAPHORE);

		exit(0);
	}

	exit(0);
}
/**
 * @brief This function increments a sequence of
	numbers in a thread-safe manner using
	semaphores to ensure mutual exclusion
 *
 * @param arg The sequence of numbers to be incremented
 */
void *function(void *arg)
{
	long int *num = (long int *)arg;
	long int *temp = num; // to get the loop_num
	int count_to_neg1 = 0;// calculate the position of -1, which is a signal to stop the loop
	while (*temp != -1)
	{
		temp++;
		count_to_neg1++;
	}
	long int loop = *(temp + 1); // to get the loop
	int i;
	switch (8 - count_to_neg1) // to get the digit
	{
	case 0:
		sem_wait(digit_one);
		sem_wait(digit_two);
		break;
	case 1:
		sem_wait(digit_three);
		sem_wait(digit_two);
		break;
	case 2:
		sem_wait(digit_three);
		sem_wait(digit_four);
		break;
	case 3:
		sem_wait(digit_five);
		sem_wait(digit_four);
		break;
	case 4:
		sem_wait(digit_five);
		sem_wait(digit_six);
		break;
	case 5:
		sem_wait(digit_seven);
		sem_wait(digit_six);
		break;
	case 6:
		sem_wait(digit_seven);
		sem_wait(digit_eight);
		break;
	case 7:
		sem_wait(digit_one);
		sem_wait(digit_eight);
		break;
	}
	
	for (i = 0; i < loop; i++)
	{
		*num = (*num + 1) % 10;
		if (*(num + 1) == -1) // check if num is the last digit of the list(except-1)
			*(num - 7) = (*(num - 7) + 1) % 10;
		else
			*(num + 1) = (*(num + 1) + 1) % 10; // if not, then add 1 to the next digit
	}
	switch (8 - count_to_neg1)
	{
		// to release the semaphore
	case 0:
		sem_post(digit_one);
		sem_post(digit_two);
		break;
	case 1:
		sem_post(digit_three);
		sem_post(digit_two);
		break;
	case 2:
		sem_post(digit_three);
		sem_post(digit_four);
		break;
	case 3:
		sem_post(digit_five);
		sem_post(digit_four);
		break;
	case 4:
		sem_post(digit_five);
		sem_post(digit_six);
		break;
	case 5:
		sem_post(digit_seven);
		sem_post(digit_six);
		break;
	case 6:
		sem_post(digit_seven);
		sem_post(digit_eight);
		break;
	case 7:
		sem_post(digit_one);
		sem_post(digit_eight);
		break;
	}
	return NULL;
}
/**
 * This function should be implemented by yourself. It must be invoked
 * in the child process after the input parameter has been obtained.
 * @parms: The input parameter from terminal.
 */
void multi_threads_run(long int input_param, long int loop_num)
{
	// Create semaphores for the shared variable.
	sem_unlink(DIGIT_ONE);
	sem_unlink(DIGIT_TWO);
	sem_unlink(DIGIT_THREE);
	sem_unlink(DIGIT_FOUR);
	sem_unlink(DIGIT_FIVE);
	sem_unlink(DIGIT_SIX);
	sem_unlink(DIGIT_SEVEN);
	sem_unlink(DIGIT_EIGHT);
	
	digit_one = sem_open(DIGIT_ONE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	digit_two = sem_open(DIGIT_TWO, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	digit_three = sem_open(DIGIT_THREE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	digit_four = sem_open(DIGIT_FOUR, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	digit_five = sem_open(DIGIT_FIVE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	digit_six = sem_open(DIGIT_SIX, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	digit_seven = sem_open(DIGIT_SEVEN, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	digit_eight = sem_open(DIGIT_EIGHT, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);

	int num_thd = 8;
	int i;
	long int digit[num_thd + 2];
	for (i = 0; i < num_thd; i++) // to get the digits of the input_param
	{
		digit[7 - i] = input_param % 10;
		input_param = input_param / 10;
	}
	digit[num_thd] = -1;		   // to mark the end of the list, to check if it is the last digit
	digit[num_thd + 1] = loop_num; // to pass the loop_num for child thread

	pthread_t list_Thread[num_thd]; // create 8 threads
	for (i = 0; i < num_thd; i++)
	{
		pthread_create(&list_Thread[i], NULL, function, &digit[i]);
	}
	for (i = 0; i < num_thd; i++)
	{
		pthread_join(list_Thread[i], NULL);
	}
	// Close and unlink semaphores.
	sem_close(digit_one);
	sem_close(digit_two);
	sem_close(digit_three);
	sem_close(digit_four);
	sem_close(digit_five);
	sem_close(digit_six);
	sem_close(digit_seven);
	sem_close(digit_eight);
	// Unlink semaphores.
	sem_unlink(DIGIT_ONE);
	sem_unlink(DIGIT_TWO);
	sem_unlink(DIGIT_THREE);
	sem_unlink(DIGIT_FOUR);
	sem_unlink(DIGIT_FIVE);
	sem_unlink(DIGIT_SIX);
	sem_unlink(DIGIT_SEVEN);
	sem_unlink(DIGIT_EIGHT);
	int output = 0;
	// print the result
	for (i = 0; i < num_thd - 1; i++)
	{
		output += digit[i];
		output *= 10;
	}
	output += digit[7];
	saveResult("p1_result.txt", output);
}