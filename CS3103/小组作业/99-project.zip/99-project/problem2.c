#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/shm.h>
#include <errno.h>
#include <assert.h>
#include <dirent.h>
#include "helpers.h"
#define BUFFER_SIZE 1048576 // 1MB size of shared memory
#define WRITE_SEMAPHORE "/write_semaphore"
#define READ_SEMAPHORE "/read_semaphore"

/**
 * @brief This function recursively traverse the source directory.
 *
 * @param dir_name : The source directory name.
 * @param filelist : The list to store the file
 * @param count : The temporary index of the filelist
 */
void traverseDir(char *dir_name, char filelist[][100], int *count);

int main(int argc, char **argv)
{
	int process_id; // Process identifier

	// The source directory.
	// It can contain the absolute path or relative path to the directory.
	char *dir_name = argv[1];

	if (argc < 2)
	{
		printf("Main process: Please enter a source directory name.\nUsage: ./main <dir_name>\n");
		exit(-1);
	}

	char filelist[100][100]; // used to save the path and file name
	int count = 0; // number of files
	int *countPtr = &count;
	int i;

	traverseDir(dir_name, filelist, countPtr);

	// Checks if the semaphore exists, if it exists we unlink him from the process.
	sem_unlink(WRITE_SEMAPHORE);
	sem_unlink(READ_SEMAPHORE);

	// Create the semaphore. sem_init() also creates a semaphore. Learn the difference on your own.
	sem_t *write_semaphore = sem_open(WRITE_SEMAPHORE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
	sem_t *read_semaphore = sem_open(READ_SEMAPHORE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);

	// Check for error while opening the semaphore
	if (write_semaphore != SEM_FAILED && read_semaphore != SEM_FAILED)
		printf("Successfully created new semaphore!\n");
	else // An error occured or a semaphore already exists
		exit(-1);

	char *shm_ptr_p, *shm_ptr_c;
	int *stop_p, *stop_c; // tell the child process to stop, if stop == 1, then stop the loop

	int shmid = shmget(IPC_PRIVATE, BUFFER_SIZE, 0666 | IPC_CREAT);
	int shmid_stop = shmget(IPC_PRIVATE, sizeof(int), 0666 | IPC_CREAT);
	if (shmid == -1)
	{
		printf("Error: shmget failed\n");
		exit(-1);
	}

	switch (process_id = fork())
	{
	default:
		/*
		 Parent Process
		*/
		printf("Parent process: My ID is %jd\n", (intmax_t)getpid());

		shm_ptr_p = (char *)shmat(shmid, 0, 0);
		stop_p = (int *)shmat(shmid_stop, 0, 0);
		stop_p[0] = 0; // set the initial value as 0
		if (shm_ptr_p == (char *)-1)
		{
			printf("Error: shmat failed\n");
			exit(-1);
		}

		for (i = 0; i < count; i++)
		{
			sem_wait(write_semaphore);
			FILE *fp = fopen(filelist[i], "r");
			if (fp == NULL)
			{
				printf("File not found!\n");
			}
			else
			{
				long length = fileLength(fp);
				while (length > BUFFER_SIZE - 1) // check if larger than the buffer size
				{
					fread(shm_ptr_p, 1, BUFFER_SIZE - 1, fp);
					shm_ptr_p[BUFFER_SIZE - 1] = '\0';
					sem_post(read_semaphore);
					sem_wait(write_semaphore);
					length -= BUFFER_SIZE - 1;
				}
				fread(shm_ptr_p, 1, length, fp);
				shm_ptr_p[length] = '\0';
				fclose(fp);
				sem_post(read_semaphore);
			}
		}
		stop_p[0] = 1;
		wait(NULL); // wait for the child process to finish
		shmdt(shm_ptr_p);
		shmdt(stop_p);
		printf("Parent process: Finished.\n");
		break;

	case 0:
		/*
		 Child Process
		*/
		printf("Child process: My ID is %jd\n", (intmax_t)getpid());

		int total_count = 0;
		shm_ptr_c = (char *)shmat(shmid, 0, 0);
		stop_c = (int *)shmat(shmid_stop, 0, 0);

		sem_wait(read_semaphore);
		while (!stop_c[0]) // loop until the parent process tell it to stop
		{
			sem_wait(read_semaphore);
			total_count += wordCount(shm_ptr_c) - 1; //discount one and later add the number of files
			sem_post(write_semaphore);
		}
		shmdt(shm_ptr_c);
		shmdt(stop_c);
		// Total word count = total space num + total '\n' num + total file num
		// wordCount = total space num + total '\n' num + 1
		// Total word count = wordCount - 1 + total file num
		// for file larger than 1MB, the number of times using wordCount != number of files
		saveResult("p2_result.txt", total_count + count);
		printf("Child process: Finished.\n");
		exit(0);

	case -1:
		/*
		Error occurred.
		*/
		printf("Fork failed!\n");
		exit(-1);
	}
	shmctl(shmid, IPC_RMID, 0);
	shmctl(shmid_stop, IPC_RMID, 0);
	sem_close(write_semaphore);
	sem_close(read_semaphore);
	sem_unlink(WRITE_SEMAPHORE);
	sem_unlink(READ_SEMAPHORE);
	exit(0);
}

/**
 * @brief This function recursively traverse the source directory.
 *
 * @param dir_name : The source directory name.
 * @param filelist : The list to store the file
 * @param count : The temporary index of the filelist
 */
void traverseDir(char *dir_name, char filelist[][100], int *count)
{
	DIR *dir;
	struct dirent *entry;
	char full_path[1024];
	if (((dir = opendir(dir_name)) == NULL))
	{
		return;
	}
	while ((entry = readdir(dir)) != NULL)
	{
		char path[1000];

		if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) // ignore "." and ".."
		{
			if (validateTextFile(entry->d_name) == 1) // it is a text file then add it
			{
				char temp[100];
				strcpy(temp, dir_name);
				strcat(temp, "/");
				strcat(temp, entry->d_name);
				strcpy(filelist[*count], temp); // add the path to the filelist
				*count += 1;
			}
			else // it is a dictory then further traverse it
			{
				// Construct new path from our base path
				strcpy(path, dir_name);
				strcat(path, "/");
				strcat(path, entry->d_name);
				traverseDir(path, filelist, count);
			}
		}
	}

	closedir(dir);
}