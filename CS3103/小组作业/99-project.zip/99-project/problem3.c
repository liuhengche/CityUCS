#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/shm.h>
#include <errno.h>
#include <assert.h>
#include <dirent.h>
#include "helpers.h"
#define BUFFER_SIZE 1048576 // 1MB size of shared memory
#define WRITE_SEMAPHORE "/write_semaphore"
#define READ_SEMAPHORE "/read_semaphore"

struct parameter // Package the data together to pass to thread function
{
    int *c_count;
    char context[1048576];
};

/**
 * @brief This function recursively traverse the source directory.
 *
 * @param dir_name : The source directory name.
 * @param filelist : The list to store the file
 * @param count : The temporary index of the filelist
 */
void traverseDir(char *dir_name, char filelist[][100], int *count);
/**
 * @brief This function increments a sequence of
	numbers in a thread-safe manner using
	semaphores to ensure mutual exclusion
 *
 * @param arg The sequence of numbers to be incremented
 */
void *function(void *args); // the function for thread

int main(int argc, char **argv)
{
    int process_id; // Process identifier
    // The source directory.
    // It can contain the absolute path or relative path to the directory.
    char *dir_name = argv[1];

    if (argc < 2)
    {
        printf("Main process: Please enter a source directory name.\nUsage: ./main <dir_name>\n");
        exit(-1);
    }
    char filelist[100][100]; // To store the relative path to the directory
    int count = 0;           // To record the count of txt files
    int *countPtr = &count;
    traverseDir(dir_name, filelist, countPtr);
    int i;

    // Checks if the semaphore exists, if it exists we unlink him from the process.
    sem_unlink(WRITE_SEMAPHORE);
    sem_unlink(READ_SEMAPHORE);

    // Create the semaphore. sem_init() also creates a semaphore. Learn the difference on your own.
    sem_t *write_semaphore = sem_open(WRITE_SEMAPHORE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);
    sem_t *read_semaphore = sem_open(READ_SEMAPHORE, O_CREAT | O_EXCL, S_IRUSR | S_IWUSR, 1);

    // Check for error while opening the semaphore
    if (write_semaphore != SEM_FAILED && read_semaphore != SEM_FAILED)
    {
        printf("Successfully created new semaphore!\n");
    }
    else
    { // An error occured or a semaphore already exists
        exit(-1);
    }

    char *shm_ptr_p, *shm_ptr_c; // Pointers to the string in the shared memory
    int *stop_p, *stop_c;        // Tell the child process to stop, if stop == 1, then stop the loop

    int shmid = shmget(IPC_PRIVATE, BUFFER_SIZE, 0666 | IPC_CREAT);
    int shmid_stop = shmget(IPC_PRIVATE, sizeof(int), 0666 | IPC_CREAT);
    if (shmid == -1)
    {
        printf("Error: shmget failed\n");
        exit(-1);
    }

    switch (process_id = fork())
    {

    default:
        /*
         Parent Process
        */
        printf("Parent process: My ID is %jd\n", (intmax_t)getpid());

        /////////////////////////////////////////////////
        // Implement your code for parent process here.
        /////////////////////////////////////////////////
        shm_ptr_p = (char *)shmat(shmid, 0, 0);
        stop_p = (int *)shmat(shmid_stop, 0, 0);
        stop_p[0] = 0;
        if (shm_ptr_p == (char *)-1)
        {
            printf("Error: shmat failed\n");
            exit(-1);
        }

        for (i = 0; i < count; i++)
        {
            sem_wait(write_semaphore); // Wait if child process is reading
            FILE *fp = fopen(filelist[i], "r");
            if (fp == NULL)
            {
                printf("File not found!\n");
            }
            else
            {
                long length = fileLength(fp);
                while (length > BUFFER_SIZE - 1) // If the file is larger tha  1MB, write and read multiple times
                {
                    fread(shm_ptr_p, 1, BUFFER_SIZE - 1, fp);
                    shm_ptr_p[BUFFER_SIZE - 1] = '\0';
                    sem_post(read_semaphore);
                    sem_wait(write_semaphore);
                    length -= BUFFER_SIZE - 1;
                }
                fread(shm_ptr_p, 1, length, fp);
                shm_ptr_p[length] = '\0';
                fclose(fp);
                sem_post(read_semaphore);
            }
        }
        stop_p[0] = 1;
        wait(NULL);
        shmdt(shm_ptr_p);
        shmdt(stop_p);
        printf("Parent process: Finished.\n");
        break;

    case 0:
        /*
         Child Process
        */
        printf("Child process: My ID is %jd\n", (intmax_t)getpid());

        /////////////////////////////////////////////////
        // Implement your code for child process here.
        /////////////////////////////////////////////////
        int total_count = 0;
        int temp = 0;
        shm_ptr_c = (char *)shmat(shmid, 0, 0);
        stop_c = (int *)shmat(shmid_stop, 0, 0);

        sem_wait(read_semaphore);
        // To save the four file contexts
        char context1[1048576];
        char context2[1048576];
        char context3[1048576];
        char context4[1048576];
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        pthread_t list_Thread[4]; // set four threads

        while (!stop_c[0])
        {
            sem_wait(read_semaphore); // Wait if parent process is writing

            switch (temp) // Save the context for each thread and let them execute
            {
            case 0:
                strcpy(context1, shm_ptr_c);
                if (list_Thread[0] == 0) // The thread has not been created or has already finished
                {
                    struct parameter *p1 = (struct parameter *)malloc(sizeof(struct parameter));
                    p1->c_count = &count1;
                    strcpy(p1->context, context1);
                    pthread_create(&list_Thread[0], NULL, function, (void *)p1);
                }
                else // The thread has been created before, wait for the prevous to finish first
                {
                    pthread_join(list_Thread[0], NULL);
                    total_count += count1;
                    struct parameter *p1 = (struct parameter *)malloc(sizeof(struct parameter));
                    p1->c_count = &count1;
                    strcpy(p1->context, context1);
                    pthread_create(&list_Thread[0], NULL, function, (void *)p1);
                }
                temp = (temp + 1) % 4;
                break;
            case 1:
                strcpy(context2, shm_ptr_c);
                if (list_Thread[1] == 0) // The thread has not been created or has already finished
                {
                    struct parameter *p2 = (struct parameter *)malloc(sizeof(struct parameter));
                    p2->c_count = &count2;
                    strcpy(p2->context, context2);
                    pthread_create(&list_Thread[1], NULL, function, (void *)p2);
                }
                else // The thread has been created before, wait for the prevous to finish first
                {
                    pthread_join(list_Thread[1], NULL);
                    total_count += count2;
                    struct parameter *p2 = (struct parameter *)malloc(sizeof(struct parameter));
                    p2->c_count = &count2;
                    strcpy(p2->context, context2);
                    pthread_create(&list_Thread[1], NULL, function, (void *)p2);
                }
                temp = (temp + 1) % 4;
                break;
            case 2:
                strcpy(context3, shm_ptr_c);
                if (list_Thread[2] == 0) // The thread has not been created or has already finished
                {
                    struct parameter *p3 = (struct parameter *)malloc(sizeof(struct parameter));
                    p3->c_count = &count3;
                    strcpy(p3->context, context3);
                    pthread_create(&list_Thread[2], NULL, function, (void *)p3);
                }
                else // The thread has been created before, wait for the prevous to finish first
                {
                    pthread_join(list_Thread[2], NULL);
                    total_count += count3;
                    struct parameter *p3 = (struct parameter *)malloc(sizeof(struct parameter));
                    p3->c_count = &count3;
                    strcpy(p3->context, context3);
                    pthread_create(&list_Thread[2], NULL, function, (void *)p3);
                };
                temp = (temp + 1) % 4;
                break;
            case 3:
                strcpy(context4, shm_ptr_c);
                if (list_Thread[3] == 0) // The thread has not been created or has already finished
                {
                    struct parameter *p4 = (struct parameter *)malloc(sizeof(struct parameter));
                    p4->c_count = &count4;
                    strcpy(p4->context, context4);
                    pthread_create(&list_Thread[3], NULL, function, (void *)p4);
                }
                else // The thread has been created before, wait for the prevous to finish first
                {
                    pthread_join(list_Thread[3], NULL);
                    total_count += count4;
                    struct parameter *p4 = (struct parameter *)malloc(sizeof(struct parameter));
                    p4->c_count = &count4;
                    strcpy(p4->context, context4);
                    pthread_create(&list_Thread[3], NULL, function, (void *)p4);
                }
                temp = (temp + 1) % 4;
                break;
            default:
                printf("Error in child process!");
                break;
            }
            sem_post(write_semaphore);
        }

        for (i = 0; i < 4; i++)
            pthread_join(list_Thread[i], NULL);
        total_count += count1;
        total_count += count2;
        total_count += count3;
        total_count += count4;

        shmdt(shm_ptr_c);
        shmdt(stop_c);
        // Total word count = total space num + total '\n' num + total file num
        saveResult("p3_result.txt", total_count + count);
        printf("Child process: Finished.\n");
        exit(0);

    case -1:
        /*
        Error occurred.
        */
        printf("Fork failed!\n");
        exit(-1);
    }
    // Delete shared memory.
    shmctl(shmid, IPC_RMID, 0);
    shmctl(shmid_stop, IPC_RMID, 0);
    // Close and delete semaphore.
    sem_close(write_semaphore);
    sem_close(read_semaphore);
    sem_unlink(WRITE_SEMAPHORE);
    sem_unlink(READ_SEMAPHORE);
    exit(0);
}

/**
 * @brief This function increments a sequence of
	numbers in a thread-safe manner using
	semaphores to ensure mutual exclusion
 *
 * @param arg The sequence of numbers to be incremented
 */

void *function(void *args)
{
    struct parameter *p = (struct parameter *)args;
    char *context = p->context;
    *(p->c_count) = wordCount(context) - 1;
    free(p);
    return NULL;
}

/**
 * @brief This function recursively traverse the source directory.
 *
 * @param dir_name : The source directory name.
 * @param filelist : The list to store the file
 * @param count : The temporary index of the filelist
 */
void traverseDir(char *dir_name, char filelist[][100], int *count)
{
    DIR *dir;
    struct dirent *entry;
    char full_path[1024];
    if (((dir = opendir(dir_name)) == NULL))
    {
        return;
    }
    while ((entry = readdir(dir)) != NULL)
    {
        char path[1000];

        if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0)
        {
            if (validateTextFile(entry->d_name) == 1)
            {
                char temp[100];
                strcpy(temp, dir_name);
                strcat(temp, "/");
                strcat(temp, entry->d_name);
                strcpy(filelist[*count], temp);
                *count += 1;
            }
            else
            {
                // Construct new path from our base path
                strcpy(path, dir_name);
                strcat(path, "/");
                strcat(path, entry->d_name);
                traverseDir(path, filelist, count);
            }
        }
    }

    closedir(dir);
}