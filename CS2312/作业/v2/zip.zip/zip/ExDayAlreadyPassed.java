public class ExDayAlreadyPassed extends Exception{
    public ExDayAlreadyPassed(){
        super("Date has already passed!");
    }
}
