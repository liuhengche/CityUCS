public interface RState {
    
    @Override
    public String toString();
}
