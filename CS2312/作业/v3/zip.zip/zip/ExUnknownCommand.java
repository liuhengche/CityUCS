public class ExUnknownCommand extends Exception{
    public ExUnknownCommand(){
        super("Unknown command");
    }
}
