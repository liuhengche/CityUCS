public class ExNotEnoughTableForSuggestion extends Exception{
    public ExNotEnoughTableForSuggestion(){
        super("Not enough tables");
    }
}
