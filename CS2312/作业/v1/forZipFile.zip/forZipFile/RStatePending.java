public class RStatePending implements RState {
    
    @Override
    public String toString() {
        return "Pending";
    }

    public RStatePending() {}
}
